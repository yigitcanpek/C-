﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

//Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Database2.accdb
namespace Proje
{
    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database2.accdb");
        DataSet ds = new DataSet();
        OleDbCommand komut = new OleDbCommand();
        OleDbDataAdapter veriadaptoru = new OleDbDataAdapter();
        DataTable tablo = new DataTable();

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            // TODO: Bu kod satırı 'ogrencino.Tablo1' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            //this.tablo1TableAdapter.Fill(this.ogrencino.Tablo1);
            listele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            {
                baglanti.Open();
                komut.Connection = baglanti;
                komut.CommandText = "Insert Into Tablo1(ogrencino, adsoyad, bolum, kayityili) Values ('" + textBox4.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox1.Text + "')";
                
                komut.ExecuteNonQuery();
                komut.Dispose();
                baglanti.Close();
                MessageBox.Show("Kayit yapilmistir!");
                ds.Clear();
                listele();

            }
            else
            {
                MessageBox.Show("Bosluk birakmayiniz!");
            }
        }   
        void listele()
        {
            baglanti.Open();
            OleDbDataAdapter veriadaptoru = new OleDbDataAdapter("Select * From Tablo1", baglanti);
            veriadaptoru.Fill(ds,"Tablo1");
            dataGridView1.DataSource = ds.Tables["Tablo1"];
            veriadaptoru.Dispose();
            baglanti.Close();
        }

        private void Sil_Click(object sender, EventArgs e) //SİLME İŞLEMİ BURADAN YAPILICAK
        {
            DialogResult c;
            c = MessageBox.Show("Silmek istediğinizden emin misiniz?", "Uyarı!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (c == DialogResult.Yes)
            {
                baglanti.Open();
                komut.Connection = baglanti;
                komut.CommandText=("Delete FROM Tablo1 where ogrencino=" + textBox5.Text + "");
                komut.ExecuteNonQuery();
                komut.Dispose();
                baglanti.Close();
                ds.Clear();
                listele();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
 
    }
}
